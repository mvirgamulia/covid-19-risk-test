<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class corona extends Model
{
    protected $table = 'corona';
}
